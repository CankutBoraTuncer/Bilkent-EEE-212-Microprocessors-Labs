#include <MKL25Z4.h>
#include "math.h"

#define pi      3.14159265358979323846
#define ADC_MAX 4095
#define SW_POS (6)
#define MASK(x) (1UL << (x))

int count=0;

const static float SINUSOIDAL[] = {0.0, 0.195, 0.383, 0.556, 0.707, 0.831, 0.924, 0.981, 1.0,
																	0.981, 0.924, 0.831, 0.707, 0.556, 0.383, 0.195, 0.0};

const static float TRIANGULAR[] = {0.0, 0.062, 0.125, 0.188, 0.25, 0.312, 0.375, 0.438, 0.5,
																	 0.562, 0.625, 0.688, 0.75, 0.812, 0.875, 0.938, 1.0};

void ADC0_init(void);
void LED_set(int s);
void LED_init(void);
void DAC0_init(void);
void delay(void);
void init_switch(void);
void triangular_wave(void);
void sinusoidal_wave(void);
void square_wave(void);
int main (void)
{		
	DAC0_init(); 
	ADC0_init();
	init_switch();
	LED_init();
	__enable_irq();

	while(1){
		if (count == 0){	
			triangular_wave();
		}
		else if(count == 1){	
			sinusoidal_wave(); 
		}
		else if(count == 2){	
			square_wave(); 
		}
	}
}
void square_wave(void){
	int result,x;
	while (count == 2) {
			ADC0->SC1[0] = 0; 
			while(!(ADC0->SC1[0] & 0x80)) { } 
			result = ADC0->R[0]; 
			LED_set(result >> 7); 
			while (count == 2) {
				
					x = result*0.75;
					DAC0->DAT[0].DATL = x & 0xff; 
					DAC0->DAT[0].DATH = (x >> 8) & 0x0f;			
					delay(); 
					x = 0;  

					DAC0->DAT[0].DATL = x & 0xff; 
					DAC0->DAT[0].DATH = (x >> 9) & 0x0f;					
					delay();
				
			break;
		}	
	}
}
void sinusoidal_wave(void){
	int result,i,x;
	while (count == 1) {
			ADC0->SC1[0] = 0; 
			while(!(ADC0->SC1[0] & 0x80)) { } 
			result = ADC0->R[0]; 
			LED_set(result >> 7); 
			while (count == 1) {
				for (i = 0; i < 17; i++) {
					x = SINUSOIDAL[i] * result; 
					DAC0->DAT[0].DATL = x & 0xff; 
					DAC0->DAT[0].DATH = (x >> 9) & 0x0f;
					delay();
				}
				break;
			}	
		}
}
void triangular_wave(void){
	int result,i,x;
	while (count == 0) {
		ADC0->SC1[0] = 0;
		while(!(ADC0->SC1[0] & 0x80)) { } 
		result = ADC0->R[0];
		LED_set(result >> 7); 
		while (count == 0) {
			for (i = 0; i < 17; i++) {
				x = TRIANGULAR[i] * result;  
				DAC0->DAT[0].DATL = x & 0xff; 
				DAC0->DAT[0].DATH = (x >> 9) & 0x0f;
				delay();
			}
			break;
		}	
	}
	count = 1;
}
void ADC0_init(void){
	SIM->SCGC5 |= 0x2000; /* clock to PORTE */
	PORTE->PCR[20] = 0; /* PTE20 analog input */
	SIM->SCGC6 |= 0x8000000; /* clock to ADC0 */
	ADC0->SC2 &= ~0x40; /* software trigger */
	/* clock div by 4, long sample time, single ended 12 bit, bus clock */
	ADC0->CFG1 = 0x40 | 0x10 | 0x04 | 0x00;
}

void LED_init(void){
	SIM->SCGC5 |= 0x400; /* enable clock to Port B */
	SIM->SCGC5 |= 0x1000; /* enable clock to Port D */
	PORTB->PCR[18] = 0x100; /* make PTB18 pin as GPIO */
	PTB->PDDR |= 0x40000; /* make PTB18 as output pin */
	PORTB->PCR[19] = 0x100; /* make PTB19 pin as GPIO */
	PTB->PDDR |= 0x80000; /* make PTB19 as output pin */
	PORTD->PCR[1] = 0x100; /* make PTD1 pin as GPIO */
	PTD->PDDR |= 0x02; /* make PTD1 as output pin */
}

void LED_set(int s){
	if (s & 1) /* use bit 0 of s to control red LED */
	PTB->PCOR = 0x40000; /* turn on red LED */
	else
	PTB->PSOR = 0x40000; /* turn off red LED */
	if (s & 2) /* use bit 1 of s to control green LED */
	PTB->PCOR = 0x80000; /* turn on green LED */
	else
	PTB->PSOR = 0x80000; /* turn off green LED */
	if (s & 4) /* use bit 2 of s to control blue LED */
	PTD->PCOR = 0x02; /* turn on blue LED */
	else
	PTD->PSOR = 0x02; /* turn off blue LED */
}

void DAC0_init(void){
	SIM->SCGC6 |= 0x80000000; /* clock to DAC module */
	DAC0->C1 = 0; /* disable the use of buffer */
	DAC0->C0 = 0x80 | 0x20 ; /* enable DAC and use software trigger */
}
void init_switch(void){
	SIM->SCGC5 |=  SIM_SCGC5_PORTD_MASK; /* enable clock for port D */

	/* Select GPIO and enable pull-up resistors and interrupts 
		on falling edges for pins connected to switches */
	PORTD->PCR[SW_POS] |= PORT_PCR_MUX(1) | PORT_PCR_PS_MASK | PORT_PCR_PE_MASK | PORT_PCR_IRQC(0x0a);
	
	/* Set port D switch bit to inputs */
	PTD->PDDR &= ~MASK(SW_POS);

	/* Enable Interrupts */
	NVIC_SetPriority(PORTD_IRQn, 64); // 0, 64, 128 or 192
	NVIC_ClearPendingIRQ(PORTD_IRQn); 
	NVIC_EnableIRQ(PORTD_IRQn);
}
void PORTD_IRQHandler(void){  
	
	// clear pending interrupts
	NVIC_ClearPendingIRQ(PORTD_IRQn);
	if ((PORTD->ISFR & MASK(SW_POS))) {
		count += 1;
		if(count == 3){count = 0;}
	}		
	// clear status flags 
	PORTD->ISFR = 0xffffffff;
}
void delay(void) 
{
	int i;
	if(count == 0){
		for(i = 0; i < 257; i++){}
	}
	else if(count == 1){
		for(i = 0; i< 257; i++){}
	}
	else if(count == 2){
		for(i = 0; i< 2450; i++){}
	}	
}




