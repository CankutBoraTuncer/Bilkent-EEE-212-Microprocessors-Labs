/* module3.c: Based on Mazidi etal book. 
 * Initialize and display "EEE212" on the first row 
 * Display the number a on the second raw as decimal and hexadecimal 
 * using 8-bit data mode.
 * Data pins use Port D, control pins use Port A.
 * Then wait until a key pressed and display the typed keys on the f
 * first row after clearing screen
 * The LCD�s data pins are connected to PORTD of the microcontroller.
 * The LCD�s RS pin is connected to Pin 2 of PORTA of the microcontroller.
 * The LCD�s R/W pin is connected to Pin 4 of PORTA of the microcontroller.
 * The LCD�s E pin is connected to Pin 5 of PORTA of the microcontroller.
 * Polling of the busy bit of the LCD status bit is used for timing.
 * Raws of the keypad are connected to PORTC 0-3, Columns are connected to PORTC4-7.
  * pull-ups are enabled
 */

#include <MKL25Z4.H>
#include <stdio.h>
#include <math.h>  
#define RS 0x04     /* PTA2 mask */ 
#define RW 0x10     /* PTA4 mask */ 
#define EN 0x20     /* PTA5 mask */
//-------------------------------------------------------------//
void Delay(volatile unsigned int time_del);
void LCD_command(unsigned char command);
void LCD_data(unsigned char data);
void LCD_init(void);
void LCD_ready(void);
void keypad_init(void);
int charToInt(char c);
void intToChar(uint32_t i, int count, int neg_flag, int zero_flag);
void firstNumberString(void);
void secondNumberString(int pos);
void resultString(int user_store, int len, int neg_flag, int zero_flag);
int calculate(uint32_t number1, uint32_t number2, char ops, int *neg_flag, int *zero_flag);
int reverseInt(int a);
void eraseChar( uint8_t *char_count, uint32_t *user_store,uint32_t *temp_store, uint32_t *temp_count);
int intLen(int number);
uint32_t keypad_getkey(void);
char input_ops(char *lookup);
int last_input(void);
void endAnimation(void);
//-------------------------------------------------------------//
int main(void)
{	
//*****************************//	
	char math_ops;	//Holds the mathematical operation																														
	char user_char; //Holds the user input from keyboard 
	char lookup[]= {'1','2','3','+','4','5','6','-','7','8','9','*',' ','0','=','/'};
	int neg_flag = 0, zero_flag = 0; //Holds the flags for negative and zero result
	uint8_t step_flag = 0; //Holds the indicator of number, if = 0 number 1, if = 1 number 2 
	uint8_t zero_flag1 = 0; //Holds the zero flag and count when a input with '0' is recieved for number 1
	uint8_t zero_flag2 = 0; //Holds the zero flag and count when a input with '0' is recieved for number 2
  uint8_t char_count = 0; //Holds the user input count
	uint32_t temp_count = 0; //Holds the previous count, number 1 count
	uint32_t user_store1 = 0; //Holds the number 1
	uint32_t temp_store1 = 0; //Holds the n-1 th user input for number 1
	uint32_t user_store2 = 0; //Holds the number 2
	uint32_t temp_store2 = 0; //Holds the n-1 th user input for number 2
	uint32_t user_input = 0; //Holds the user input
	uint32_t key; //Holds the raw keyboard input 
//*****************************//	
	LCD_init();
  firstNumberString();				
		keypad_init();
    while(keypad_getkey() == 0)
    {
		}
		while(1)
		{
		Delay(300000);	
		key=keypad_getkey();	
			if(key != 0)
			{			
				//This block is for LCD output when a operation is recieved 
				if(!step_flag){if(user_char == '+' || user_char == '-' || user_char == '*'|| user_char == '/'){LCD_command(0x80+char_count);}}
				
				user_char = lookup[key-1];
				
				//The code goes under this branch when the second number will be recieved
				if(char_count == 6 || user_char == '+' || user_char == '-' || user_char == '*'|| user_char == '/'|| step_flag){
					
					//This branch is to reinitalize for the second number
					if(!step_flag){				
						step_flag += 1;
						secondNumberString(char_count);
						temp_count = char_count;
						char_count = 0;
						math_ops = user_char;						
						if(temp_count == 6){
							math_ops = input_ops(lookup);		
						}
						else{
							LCD_data(lookup[key-1]);
						}
						temp_count += 1;						
					}		
					//This branch is to give the output
					else{	
						if(char_count == 6 || user_char == '='){
							user_store1 = reverseInt(user_store1);
							user_store2 = reverseInt(user_store2);
							if(zero_flag1){
								user_store1 = user_store1*pow(10,zero_flag1);
								zero_flag1=0;
							}
							if(zero_flag2){
								user_store2 = user_store2*pow(10,zero_flag2);
								zero_flag2=0;
							}															
							user_store1 = calculate(user_store1, user_store2, math_ops, &neg_flag, &zero_flag);
							resultString(user_store1, intLen(user_store1), neg_flag, zero_flag);
						}
						//This branch is to recieve the second number
						else{
							LCD_data(lookup[key-1]);
							char_count += 1;
							//THIS PART IS FOR BONUS 2 +10
							if(user_char == ' '){
								eraseChar(&char_count, &user_store2, &temp_store2, &temp_count);
							}						
							else{
								user_input = charToInt(user_char);
								if(user_input == 0){
									zero_flag2 +=1;		
								}
								else{
									zero_flag2 = 0;
									temp_store2 = user_input*pow(10, char_count-1);
									user_store2 += temp_store2;
								}
							}	
						}					
					}	
				}
				//The code goes under this branch when the first number will be recieved
				else{
					LCD_data(lookup[key-1]);	
					char_count += 1;
					//THIS PART IS FOR BONUS 2 +10
					if(user_char == ' '){
						eraseChar(&char_count, &user_store1, &temp_store1, &temp_count);
					}
					//This branch is block the user to input '=' when the first number is being writen
					else if (user_char == '='){
						LCD_command(0x80+char_count - 1);
						LCD_data(' ');
						LCD_command(0x80+char_count - 1);
						char_count -= 1;						
					}
					else{
						user_input = charToInt(user_char);
						//This branch is to indicate that when '0' is the last user input
						if(user_input == 0){
							zero_flag1 +=1;		
						}
						else{
							zero_flag1 = 0;
							temp_store1 = user_input*pow(10, char_count-1);
							user_store1 += temp_store1;
						}
					}
				}				
			Delay(300000);		
			key =0;
				
		}
	}
}

void LCD_init(void)
{
    SIM->SCGC5 |= 0x1000;       /* enable clock to Port D */ 
    PORTD->PCR[0] = 0x100;      /* make PTD0 pin as GPIO */
    PORTD->PCR[1] = 0x100;      /* make PTD1 pin as GPIO */
    PORTD->PCR[2] = 0x100;      /* make PTD2 pin as GPIO */
    PORTD->PCR[3] = 0x100;      /* make PTD3 pin as GPIO */
    PORTD->PCR[4] = 0x100;      /* make PTD4 pin as GPIO */
    PORTD->PCR[5] = 0x100;      /* make PTD5 pin as GPIO */
    PORTD->PCR[6] = 0x100;      /* make PTD6 pin as GPIO */
    PORTD->PCR[7] = 0x100;      /* make PTD7 pin as GPIO */
    PTD->PDDR = 0xFF;           /* make PTD7-0 as output pins */
    
    SIM->SCGC5 |= 0x0200;       /* enable clock to Port A */ 
    PORTA->PCR[2] = 0x100;      /* make PTA2 pin as GPIO */
    PORTA->PCR[4] = 0x100;      /* make PTA4 pin as GPIO */
    PORTA->PCR[5] = 0x100;      /* make PTA5 pin as GPIO */
    PTA->PDDR |= 0x34;          /* make PTA5, 4, 2 as output pins */
    
    LCD_command(0x38);      /* set 8-bit data, 2-line, 5x7 font */
    LCD_command(0x01);      /* clear screen, move cursor to home */
    LCD_command(0x0F);      /* turn on display, cursor blinking */
}

/* This function waits until LCD controller is ready to
 * accept a new command/data before returns.
 */
void LCD_ready(void)
{
    uint32_t status;
    
    PTD->PDDR = 0x00;          /* PortD input */
    PTA->PCOR = RS;         /* RS = 0 for status */
    PTA->PSOR = RW;         /* R/W = 1, LCD output */
    
    do {    /* stay in the loop until it is not busy */
			  PTA->PCOR = EN;
			  Delay(500);
        PTA->PSOR = EN;     /* raise E */
        Delay(500);
        status = PTD->PDIR; /* read status register */
        PTA->PCOR = EN;
        Delay(500);			/* clear E */
    } while (status & 0x80UL);    /* check busy bit */
    
    PTA->PCOR = RW;         /* R/W = 0, LCD input */
    PTD->PDDR = 0xFF;       /* PortD output */
}

void LCD_command(unsigned char command)
{
    LCD_ready();			/* wait until LCD is ready */
    PTA->PCOR = RS | RW;    /* RS = 0, R/W = 0 */
    PTD->PDOR = command;
    PTA->PSOR = EN;         /* pulse E */
    Delay(500);
    PTA->PCOR = EN;
}

void LCD_data(unsigned char data)
{
    LCD_ready();			/* wait until LCD is ready */
    PTA->PSOR = RS;         /* RS = 1, R/W = 0 */
    PTA->PCOR = RW;
    PTD->PDOR = data;
    PTA->PSOR = EN;         /* pulse E */
    Delay(500);
    PTA->PCOR = EN;
}

/* Delay n milliseconds
 * The CPU core clock is set to MCGFLLCLK at 41.94 MHz in SystemInit().
 */

/* delay n microseconds
 * The CPU core clock is set to MCGFLLCLK at 41.94 MHz in SystemInit().
 */


void Delay(volatile unsigned int time_del) {
  while (time_del--) 
		{
  }
}


void keypad_init(void)
{
    SIM->SCGC5 |= 0x0800;       /* enable clock to Port C */ 
    PORTC->PCR[0] = 0x103;      /* make PTC0 pin as GPIO and enable pullup*/
    PORTC->PCR[1] = 0x103;      /* make PTC1 pin as GPIO and enable pullup*/
    PORTC->PCR[2] = 0x103;      /* make PTC2 pin as GPIO and enable pullup*/
    PORTC->PCR[3] = 0x103;      /* make PTC3 pin as GPIO and enable pullup*/
    PORTC->PCR[4] = 0x103;      /* make PTC4 pin as GPIO and enable pullup*/
    PORTC->PCR[5] = 0x103;      /* make PTC5 pin as GPIO and enable pullup*/
    PORTC->PCR[6] = 0x103;      /* make PTC6 pin as GPIO and enable pullup*/
    PORTC->PCR[7] = 0x103;      /* make PTC7 pin as GPIO and enable pullup*/
    PTC->PDDR = 0x00;         /* make PTC7-0 as input pins */
}




uint32_t keypad_getkey(void)
{
    uint32_t row, col;
    const char row_select[] = {0x01, 0x02, 0x04, 0x08}; /* one row is active */

    /* check to see any key pressed */
    PTC->PDDR |= 0x0F;          /* rows output */
    PTC->PCOR = 0x0F;               /* ground rows */
    Delay(500);                 /* wait for signal return */
    col =  PTC->PDIR & 0xF0UL;     /* read all columns */
    PTC->PDDR = 0;              /*  rows input */
    if (col == 0xF0UL)
        return 0;               /* no key pressed */

    /* If a key is pressed, it gets here to find out which key.
     * It activates one row at a time and read the input to see
     * which column is active. */
    for (row = 0; row < 4; row++)
    {
        PTC->PDDR = 0;                  /* disable all rows */
        PTC->PDDR |= row_select[row];   /* enable one row */
        PTC->PCOR = row_select[row];    /* drive the active row low */
        Delay(500);                     /* wait for signal to settle */
        col = PTC->PDIR & 0xF0UL;         /* read all columns */
        if (col != 0xF0UL) break;         /* if one of the input is low, some key is pressed. */
    }
    PTC->PDDR = 0;                      /* disable all rows */
    if (row == 4) 
        return 0;                       /* if we get here, no key is pressed */
 
    /* gets here when one of the rows has key pressed, check which column it is */
    if (col == 0xE0UL) return row * 4 + 1;    /* key in column 0 */
    if (col == 0xD0UL) return row * 4 + 2;    /* key in column 1 */
    if (col == 0xB0UL) return row * 4 + 3;    /* key in column 2 */
    if (col == 0x70UL) return row * 4 + 4;    /* key in column 3 */

    return 0;   /* just to be safe */
}

int charToInt(char c){
	int num = 0;
	num = c - '0';
	return num;
}


void intToChar(uint32_t i, int count, int neg_flag, int zero_flag){
{	
	char str[20];
	int t;
	if(zero_flag){LCD_data('0');for(t=0; t<15; ++t){LCD_data(' ');}return;}
	if(neg_flag){LCD_data('-');}
  sprintf(str, "%d", i);
	for(t=0; t<16; ++t){
		if(t<count-1){LCD_data(str[t]);}
		else{LCD_data(' ');}
		}
	}
}
int reverseInt(int a){
	int reverse = 0, remainder;
  while (a != 0) {
    remainder = a % 10;
    reverse = reverse * 10 + remainder;
    a /= 10;
  }
  return reverse;
}


void firstNumberString(void){
	LCD_command(0xC0);      
	LCD_data('E');          
	LCD_data('N');
	LCD_data('T');
	LCD_data('E');
	LCD_data('R');
	LCD_data(' ');
	LCD_data('1');
	LCD_data('S');          
	LCD_data('T');
	LCD_data(' ');
	LCD_data('N');
	LCD_data('U');
	LCD_data('M');
	LCD_data('B');
	LCD_data('E');
	LCD_data('R');          
	LCD_command(0x80); 
}

void secondNumberString(int pos){
	LCD_command(0xC0);     
	LCD_data('E');          
	LCD_data('N');
	LCD_data('T');
	LCD_data('E');
	LCD_data('R');
	LCD_data(' ');
	LCD_data('2');
	LCD_data('N');          
	LCD_data('D');
	LCD_data(' ');
	LCD_data('N');
	LCD_data('U');
	LCD_data('M');
	LCD_data('B');
	LCD_data('E');
	LCD_data('R');          
	LCD_command(0x80 + pos);  
}

void resultString(int user_store, int len, int neg_flag, int zero_flag){
	LCD_command(0xC0); 
	intToChar(user_store, len, neg_flag, zero_flag);
	last_input();
	endAnimation();
}

void endAnimation(void){
	int i = 0, rev = 0;
	while(1){
		LCD_command(0x01);		
		LCD_command(0x80);
		LCD_data('-');
		LCD_data('-');
		LCD_data('-');
		LCD_data('P');
		LCD_data('U');
		LCD_data('S');
		LCD_data('H');		
		LCD_data(' ');	
		LCD_data('R');	
		LCD_data('E');	
		LCD_data('S');	
		LCD_data('E');
		LCD_data('T');
		LCD_data('-');
		LCD_data('-');
		LCD_data('-');			
		LCD_command(0xC0 + i);
		LCD_data('M');
		LCD_data('A');
		LCD_data('D');
		LCD_data('E');
		LCD_data(' ');
		LCD_data('B');
		LCD_data('Y');		
		LCD_data(' ');	
		LCD_data('C');	
		LCD_data('B');	
		LCD_data('T');	
		if(i== 5 || rev){	
			i-=1;
			rev = 1;
			if(i == 0){rev = 0;}
		}
		else{i+=1;}
		Delay(1000000);
	}
}
int calculate(uint32_t number1, uint32_t number2, char ops, int *neg_flag, int *zero_flag){
	if(ops == '+'){number1+=number2;}
	if(ops == '-'){		
		if(number1 < number2){*neg_flag=1;number1 = number2-number1;}
		else{number1-=number2;}
	}
	if(ops == '*'){number1*=number2;}
	if(ops == '/'){number1/=number2;}
	if(number1 == 0){*zero_flag = 1;}
	return number1;
}
int intLen(int number){
	int i = 1;
	while(number>0){
		number /= 10;
		i += 1;	
	}
	return i;
}
void eraseChar( uint8_t *char_count, uint32_t *user_store,uint32_t *temp_store, uint32_t *temp_count){
	LCD_command(0x80+*temp_count+*char_count - 2);
	LCD_data(' ');
	*user_store -= *temp_store;
	LCD_command(0x80+ *temp_count + *char_count - 2);
	*char_count -= 2;
}

char input_ops(char *lookup){
	uint32_t key;
	char c;
	while(keypad_getkey() == 0){}
	while(1){
		Delay(300000);	
		key=keypad_getkey();
		if(key != 0){
			c = lookup[key-1];
			if(c == '+' || c == '-' || c == '*'|| c == '/'){
				LCD_data(lookup[key-1]);
				return c;	
			}
		}
	}
}
int last_input(void){
	uint32_t key;
	Delay(1000000);
	while(keypad_getkey() == 0){}
	while(1){
		Delay(300000);	
		key=keypad_getkey();
		if(key != 0){
			return 0;
		}
	}
}
